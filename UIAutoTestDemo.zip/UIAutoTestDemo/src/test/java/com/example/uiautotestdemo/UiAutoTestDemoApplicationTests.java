package com.example.uiautotestdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UiAutoTestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
